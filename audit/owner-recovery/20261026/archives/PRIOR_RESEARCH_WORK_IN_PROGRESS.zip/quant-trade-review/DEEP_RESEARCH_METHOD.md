# Independent Quant-Trade research architecture review — protocol

Protocol registered 2026-10-26 before external searches. This is an architecture research review, not a repository build, code audit, or trading-performance validation. Review files are outside the repository. Target implementation: `0691a4c1c905c8cfa1e68d521b12d66655ec4dd3`; baseline: `2b99d8aeb8a342f1ef32544247d366cb8a26037e`.

## Questions and rival explanations

1. Is the binding missing function admission, source access, intentional investigation, experimental search, research accounting, or downstream validation?
2. Does deep investigation require separate capability, deployment subsystem, and UI? Test these independently.
3. Is Proposal Ledger enough to register the scientific denominator, including questions that never generate a proposal and numerical variants that never leave a search?
4. Does adding source volume improve distinct testable questions, or mainly increase correlated hypotheses, cost, and selection bias?
5. Could the simplest architecture reuse existing Research Intelligence, Scientific Memory, source planner, and Control Plane instead of adding competing authorities?

## Search protocol

Search all 20 user-specified families, with independent positive and negative searches. Prioritize original papers, official regulatory/central-bank publications, original researcher/organization accounts, open replication artifacts, and formal workflow/registry specifications. Use secondary accounts only as leads. Trace important assertions to accessible original evidence. Inspect abstract/full text and methods/results when available; mark access precisely. An inaccessible full text is not a full-text review. Do not count search-result leads as reviewed evidence. Archive tool retrieval text and queries under `evidence/`.

For each material source capture the requested ledger fields plus URL, access date, overlap group, and inspection depth. Distinguish direct evidence from transfer from another scientific domain and from our architectural inference. Search failures and nulls as well as successful mechanisms. For every apparent success ask for the attempted-research denominator, transaction/capacity costs, post-publication/prospective evidence, and selection limitations.

## Synthesis and stopping

No pooled success rate across overlapping anomaly panels or selected practitioners. No causal ranking of source engines from published survivors. Architecture scores are ordinal engineering judgments, not measured economic yields. Seek multiple independent source families for each major conclusion. Stop family expansion after additional searches cease to change the decision, expose a meaningful contradiction, or identify a material boundary; disclose unresolved families, access limits, and non-systematic coverage. This is targeted saturation for architectural decisions, not an exhaustive systematic literature review or proof of the highest-yield strategy.

## Repository evidence

Inspect exact target objects read-only; distinguish executable contracts, tests, documentation, and operational qualification reports. Do not treat documentation or passing tests as proof of live operation or economic validity. Record file/line and commit anchors. Do not modify the checkout, run production workflows, create Candidates, or conduct experiments. No prior research source ledger was supplied; user conclusions are hypotheses to challenge, not inherited evidence.

## Confidence

Use HIGH / MEDIUM / LOW / UNKNOWN_DUE_TO_MISSING_DENOMINATOR / UNKNOWN_DUE_TO_PRIVATE_INFORMATION / UNKNOWN_DUE_TO_INSUFFICIENT_EVIDENCE. Scope each confidence to its claim. Knowledge of public historical outcomes and unknown model pretraining cannot be erased by using historical point-in-time prices.
